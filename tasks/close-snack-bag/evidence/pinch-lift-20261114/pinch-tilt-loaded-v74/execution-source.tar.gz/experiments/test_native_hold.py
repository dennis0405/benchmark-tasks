"""Gate regressions: finite motion or final-only geometry cannot imply success."""
from copy import deepcopy
import unittest
from verify_native_hold import evaluate


class HoldGateTest(unittest.TestCase):
    def example(self):
        result = {'all_finite': True, 'opposed_contact_faces':True,'substeps': 10, 'geometry': {'states_checked': 1811,
                  'checks_per_state_min':1,'checks_per_state_max':1,
                  'clip_intrusion_states': 0, 'self_crossing_states': 0, 'ground_intrusion_states': 0,
                  'clip_self_intrusion_states':0}}
        shapes = {'shape_body': [0, 1], 'shape_local': [[.022, 0, -.004], [.022, 0, .004]],
                  'shape_scale': [[.022, .05, .003]]*2}
        trace = [{'step': i+1, 'shape_fold_contacts': {str(j): {'active_fold_contacts': 5,
            'fold_contact_y_span_m': .1} for j in (0, 1)}, 'fold_centroid_clip_local_m': [.025, 0, .002],
            'clip_root_pose': [.184, 0, .01], 'jaw_angle_rad': -.1} for i in range(181)]
        return result, trace, shapes

    def test_full_three_seconds_required(self):
        args = self.example()
        self.assertTrue(evaluate(*args)['passed'])
        args[0]['geometry']['states_checked'] = 1801
        self.assertFalse(evaluate(args[0], args[1][:-1], args[2])['passed'])

    def test_early_intrusion_rejects_final_stable_window(self):
        result, trace, shapes = self.example()
        result['geometry']['clip_intrusion_states'] = 1
        self.assertFalse(evaluate(result, trace, shapes)['passed'])

    def test_missing_jaw_contact_slip_and_joint_limit_each_reject(self):
        for change in ('contact', 'slip', 'joint', 'self_crossing', 'ground', 'clip_self'):
            result, trace, shapes = deepcopy(self.example())
            if change == 'contact':
                trace[90]['shape_fold_contacts']['1']['active_fold_contacts'] = 0
            elif change == 'slip':
                trace[90]['fold_centroid_clip_local_m'][0] += .01
            elif change == 'joint':
                trace[90]['jaw_angle_rad'] = .5
            elif change == 'self_crossing':
                result['geometry']['self_crossing_states'] = 1
            elif change == 'ground':
                result['geometry']['ground_intrusion_states'] = 1
            else:
                result['geometry']['clip_self_intrusion_states'] = 1
            with self.subTest(change=change):
                self.assertFalse(evaluate(result, trace, shapes)['passed'])

    def test_nonfinite_rigid_measurements_reject(self):
        for field in ('jaw_angle_rad', 'fold_centroid_clip_local_m', 'clip_root_pose'):
            result, trace, shapes = deepcopy(self.example())
            if field == 'jaw_angle_rad':
                trace[90][field] = float('nan')
            else:
                trace[90][field][0] = float('nan')
            with self.subTest(field=field):
                self.assertFalse(evaluate(result, trace, shapes)['passed'])

    def test_unchecked_or_duplicate_physics_states_reject(self):
        for field,value in (('checks_per_state_min',0),('checks_per_state_max',2)):
            result,trace,shapes=deepcopy(self.example())
            result['geometry'][field]=value
            with self.subTest(field=field):
                self.assertFalse(evaluate(result,trace,shapes)['passed'])

    def test_segmented_jaw_requires_load_on_every_pad(self):
        result,trace,shapes=self.example()
        shapes['jaw_shape_groups']=[[0],[1,2,3,4,5]]
        for row in trace:
            for sid,y in enumerate((-.04,-.02,0,.02,.04),start=1):
                row['shape_fold_contacts'][str(sid)]={'active_fold_contacts':2,
                    'fold_contact_y_span_m':.018,'fold_contact_y_min_m':y-.009,'fold_contact_y_max_m':y+.009}
        self.assertTrue(evaluate(result,trace,shapes)['passed'])
        trace[90]['shape_fold_contacts']['3']['active_fold_contacts']=0
        self.assertFalse(evaluate(result,trace,shapes)['passed'])


if __name__ == '__main__':
    unittest.main()
